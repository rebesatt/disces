import shutil
import os
import sys

def update_from_local_git_repository():
    files = ["discovery.py",
             "discovery_bottom_up.py",
             "discovery_bu_pattern_type_split.py",
             "discovery_bu_multidim.py",
             "discovery_bu_pts_multidim.py",
             "discovery_il_miner.py",
             "error.py",
             "generator.py",
             "generator_multidim.py",
             "hyper_linked_tree.py",
             "query.py",
             "query_multidim.py",
             "sample.py",
             "sample_multidim.py",
             ]
    for file_name in files:
        try:
            shutil.copyfile(files_rel_dir + "/" + file_name, script_abs_dir + file_name)
            print("Successfully updated '" + file_name + "'")
        except:
            print("Unable to update '" + file_name + "'.")

if __name__ == "__main__":
    current_wd = os.getcwd()

    script_abs_dir = os.path.abspath(__file__).replace("file_updater.py", "")
    os.chdir(script_abs_dir)
    files_rel_dir = "../../prototype-query-discovery"

    if not os.path.isdir(files_rel_dir):
        print("Path to 'prototype-query-discovery' not found")
        sys.exit(1)

    update_from_local_git_repository()

    os.chdir(current_wd)
