import os
import sys
import gzip

CURRENT_WD = os.getcwd()

EXPERIMENT_DIR = os.path.abspath(__file__).replace("xy.py", "")
os.chdir(EXPERIMENT_DIR)
os.chdir("../src")
SRC_DIR = os.getcwd()

os.chdir(EXPERIMENT_DIR)
sys.path.insert(0, SRC_DIR)

from sample_multidim import MultidimSample
from discovery_bu_pts_multidim import discovery_bu_pts_multidim

if __name__=="__main__":
    trace_length = 39
    sample_size = 250
    sample_path = '../datasets/finance/finance_query3.txt.gz'
    sample_list = []
                        
    counter = 0
    file = gzip.open(sample_path, 'rb')
    for trace1 in file:
        if counter == sample_size:
            break
    
        trace = ' '.join(trace1.decode().split()[-trace_length:])
        sample_list.append(trace)
                            
    
        counter += 1
    file.close()

    sample = MultidimSample(sample_list)

    discovery_bu_pts_multidim(sample, 1.0, use_tree_structure=True, use_smart_matching=True, max_query_length=4)
