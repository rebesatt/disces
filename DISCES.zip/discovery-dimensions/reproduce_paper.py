"""
"""
import zipfile
import shutil
import os
import sys
import subprocess
import datetime
import argparse
import requests
from timeit import default_timer as timer
from argparse import RawTextHelpFormatter

PROJECT_NAME = "DISCES"
VERSION = "0.2.1"
ZIP_LOCATION = "https://github.com/rebesatt/disces/blob/Feature-Download-via-reproduce_paper-script/test.zip"
ZIP_LOCATION = "https://anonymous.4open.science/api/repo/disces-0E5B/file/test.zip"


def print_to_std_and_file(str_to_log):
    print(str_to_log)
    with open(log_file, 'a') as f:
        current_timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        f.write(current_timestamp + ": " + str_to_log + "\n")

def verify_requirements():
    # TODO: Check LaTeX-Version and packages
    if not (sys.version_info.major == 3 and sys.version_info.minor >= 10):
        print_to_std_and_file("Running this script requries Python >= 3.10. Current versions is " + str(sys.version_info.major) + "." + str(sys.version_info_minor))
        sys.exit(1)
    if not shutil.which("latex"):
        print_to_std_and_file("Note: Reporducing this script requries LaTeX. Not LaTeX installation fount.")

def execute_shell_command(cmd, stdout_verification=None, b_stderr_verification=False):
    print_to_std_and_file("Executed command: " + cmd)
    result = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print_to_std_and_file("STDOUT:")
    print_to_std_and_file(str(result.stdout)[2:-1].replace("\\r", '\r').replace("\\n", '\n'))
    print_to_std_and_file("STDERR:")
    print_to_std_and_file(str(result.stderr)[2:-1].replace("\\r", '\r').replace("\\n", '\n'))

    if stdout_verification is not None:
        if stdout_verification not in result.stdout.decode():
            print_to_std_and_file("Verification string " + stdout_verification + " not in stdout")
            raise Exception
    if b_stderr_verification:
        if result.stderr != "b''":
            print_to_std_and_file("stderr is not empty: " + str(result.stderr[2:-1]))
            raise Exception

def execute_shell_command_with_live_output(cmd):
    print_to_std_and_file("Executed command: " + cmd)
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while True:
        output = process.stdout.readline()
        if process.poll() is not None:
            break
        if output:
            print(output.strip().decode('utf-8'))
    rc = process.poll()
    if rc != 0:
        print_to_std_and_file("RC not 0 (RC=" + str(rc) + ") for command: " + cmd)
        raise Exception
    return rc

def download_repository():
    script_abs_dir = os.path.abspath(__file__).replace("reproduce_paper.py", "")
    #if os.path.isdir(script_abs_dir + "datasets/") and os.path.isdir(script_abs_dir + "docs/") and os.path.isdir(script_abs_dir + "experiments/"):
    #    print_to_std_and_file("The reproduce_paper.py script is part of a '" + PROJECT_NAME + "' project. No files will be downloaded.")
    #    project_root = script_abs_dir
    #    #TODO:
    #    print_to_std_and_file("Update python-scripts for algorithms and experiments locally.")
    #    execute_shell_command('python src/file_updater.py')
    #    return project_root

    print_to_std_and_file("The reproduce_paper.py script is a standalone. Downloading '" + PROJECT_NAME + "'s source code.")
    #TODO: remove next and uncomment second if the zip is not called 'test' anymore
    zipped_project = script_abs_dir + "test.zip"
    # zipped_project = script_abs_dir + "/" + PROJECT_NAME + ".zip"
    project_root = script_abs_dir + PROJECT_NAME

    downloaded_anything = True
    if downloaded_anything:
        zipped_project = 'test.zip'
        response = requests.get(ZIP_LOCATION)
        if response.status_code == 200:
            with open(zipped_project, 'wb') as file:
                file.write(response.content)
            print_to_std_and_file("Successfully downloaded '" + PROJECT_NAME + "'s source code to " + zipped_project + ".")
        else:
            print_to_std_and_file("Download failed. Status code " + response.status_code)

        print_to_std_and_file("Extract " + zipped_project + ".")
        with zipfile.ZipFile(zipped_project, 'r') as zip_ref:
            zip_ref.extractall(".temp_" + PROJECT_NAME)
        os.remove(zipped_project)
        print_to_std_and_file("All files extracted and " + zipped_project + " deleted.")

        if os.path.isdir(project_root):
            #TODO: remove next and uncomment second if the zip is not called 'test' anymore
            shutil.copytree(".temp_" + PROJECT_NAME + "/test", PROJECT_NAME, dirs_exist_ok=True)
            #shutil.copytree(".temp_" + PROJECT_NAME + "/" + PROJECT_NAME, PROJECT_NAME, dirs_exist_ok=True)
            print_to_std_and_file("Found existing local project " + project_root + ". Merge repository updates to it.")
        else:
            #TODO: remove next and uncomment second if the zip is not called 'test' anymore
            shutil.move(".temp_" + PROJECT_NAME + "/test", PROJECT_NAME)
            #shutil.move(".temp_" + PROJECT_NAME + "/" + PROJECT_NAME, PROJECT_NAME)
            print_to_std_and_file("Downloaded the project to " + project_root)
        shutil.rmtree(".temp_" + PROJECT_NAME)

    return project_root

def create_synthetic_data():
    script_abs_dir = os.path.abspath(__file__).replace("reproduce_paper.py", "")
    os.chdir("datasets/synt/")
    execute_shell_command_with_live_output("python synt_sample_generator.py")
    os.chdir(script_abs_dir)

def create_verification_file(local_result_dir, file_to_verify_execution):
    f = open(local_result_dir + "/" + file_to_verify_execution, "w")
    f.write("Done")
    f.close()

def run_experiments(local_result_dir, run_command_prefix, functions, test_name_prefix, file_to_verify_execution, args=None, estimated_runtimes=None):
    if os.path.isfile(local_result_dir + "/" + file_to_verify_execution):
        print_to_std_and_file("Found existing test folder. Skipping.")
    else:
        b_create_verification_file = True
        for i, function in enumerate(functions):
            cmd = str(run_command_prefix) + " " + str(test_name_prefix) + str(function) + ".py"
            if args:
                cmd += " " + str(args[i])
            if estimated_runtimes:
                print_to_std_and_file("Experiment " + str(test_name_prefix) + str(function) + " estimated runtime is " + str(estimated_runtimes[i]) + " seconds")
            try:
                start = timer()
                execute_shell_command_with_live_output(cmd)
                end = timer()
                print_to_std_and_file("Experiment " + str(test_name_prefix) + str(function) + " took " + str(end - start) + " seconds")
            except Exception as msg:
                end = timer()
                print_to_std_and_file(str(msg))
                print_to_std_and_file("Experiment " + str(test_name_prefix) + str(function) + " failed after " + str(end - start) + " seconds")
                b_create_verification_file = False
        if b_create_verification_file:
            create_verification_file(local_result_dir, file_to_verify_execution)
    assert os.path.isfile(local_result_dir + "/" + file_to_verify_execution)

def compile_main_pdf():
    figure_list = {"Figure 1": "sota_4_broken.pdf",
                   "Figure 2": "rl_compare.pdf",
                   "Figure 3": "synt_plots.pdf",
                   "Figure 4": "cluster.pdf",
                   "Figure 5": "exclude.pdf"}
    for figure_name, figure_file in figure_list.items():
        if not os.path.isfile(local_result_dir + "/" + figure_file):
            print_to_std_and_file("Note: " + figure_name + " (" + figure_file + ") wasn't found in " + local_result_dir + ". Using the original figure from the paper.")
        else:
            if not os.path.isdir(project_root + "docs/latex_src/original_img"):
                os.makedirs(project_root + "docs/latex_src/original_img")
                print_to_std_and_file("'" + project_root + "docs/latex_src/original_img' created.")
            if not os.path.isfile(project_root + "docs/latex_src/original_img/" + figure_file):
                shutil.copyfile(project_root + "docs/latex_src/img/" + figure_file, project_root + "docs/latex_src/original_img/" + figure_file)
                print_to_std_and_file("Saved original " + figure_name + " (" + figure_file + ") in '" + project_root + ".docs/latex_src/original_img/'")
            shutil.copyfile(local_result_dir + "/" + figure_file, project_root + "docs/latex_src/img/" + figure_file)
            print_to_std_and_file("Replaced " + figure_name + " (" + figure_file + ") with the reproduced one. Original file can be found in '" + project_root +
                    "docs/latex_src/original_img/")

    os.chdir(project_root + "docs/latex_src/")

    execute_shell_command('pdflatex --interaction=nonstopmode main.tex')
    execute_shell_command('bibtex main.aux')
    execute_shell_command('pdflatex --interaction=nonstopmode main.tex')
    execute_shell_command('pdflatex --interaction=nonstopmode main.tex', stdout_verification="main.pdf")

    shutil.copyfile("main.pdf", reproduced_main_pfd_file)
    print_to_std_and_file("The reproduced paper, containing the new figures based on these experiments, is in " + reproduced_main_pfd_file)

def clean_working_directory():
    #os.remove("*.log")
    shutil.rmtree("datasets/synt/domain_size/", ignore_errors=True)
    shutil.rmtree("datasets/synt/max_pattern/", ignore_errors=True)
    shutil.rmtree("datasets/synt/max_type/", ignore_errors=True)
    shutil.rmtree("datasets/synt/trace_length/", ignore_errors=True)
    shutil.rmtree("datasets/synt/traces/", ignore_errors=True)
    shutil.rmtree("datasets/synt/types/", ignore_errors=True)
    #TODO:
    #docs latexmk -C
    #execute_shell_command('pdflatex --interaction=nonstopmode main.tex', stdout_verification="main.pdf")
    shutil.rmtree("experiments/experiment_results/", ignore_errors=True)

if __name__ == "__main__":
    # Setup
    parser = argparse.ArgumentParser(description =  "Reproduce ...\n"
            "Requirements:\n"
            "(1) Python >= 3.10",
            formatter_class=RawTextHelpFormatter)
    parser.add_argument("--dd", dest="b_download_dataset",
            help="if --dd is specified, the script only downloads the repository and external datasets and exits (without running any experiments)",
            action='store_true')
    parser.add_argument("--ilm", dest="b_run_extended_il_miner",
            help="",
            action="store_true")
    parser.add_argument("--noexp", dest="b_run_no_experiment",
            help="",
            action="store_true")
    parser.add_argument("--C", dest="b_clean_working_directory",
            help="",
            action="store_true")
    #TODO: parser.add_argument("--vv", dest="b_run_extended_il-miner", help="", action="store_true")
    args = parser.parse_args()

    if args.b_clean_working_directory:
        clean_working_directory()
        sys.exit()

    log_file = os.path.abspath(__file__).replace("reproduce_paper.py", "reproduce_paper.log")
    reproduced_main_pfd_file = os.path.abspath(__file__).replace("reproduce_paper.py", "main.pdf")
    print_to_std_and_file("======================== Reproduce '" + PROJECT_NAME + "'s Experiments ========================")
    print("The script log is at %s", str(log_file))

    verify_requirements()

    project_root = download_repository()
    create_synthetic_data()
    if args.b_download_dataset:
        sys.exit()

    # Run the experiments
    try:
        local_result_dir = os.getcwd() + "/experiments/experiment_results"
        try:
            os.makedirs(local_result_dir)
            print_to_std_and_file("'" + local_result_dir + "' created.")
        except FileExistsError:
            pass
        if not args.b_run_no_experiment:
            functions = {# "[Name]" : "[Runtime]"
                    "cluster" : "-",
                    "correlation" : "-",
                    "exclude" : "-",
                    "rl_compare" : "-",
                    "sota_4_broken" : "-",
                    "sota_acc" : "-",
                    "synt_plot" : "-",
                    }
            run_ilm = ""
            if args.b_run_extended_il_miner:
                run_ilm = "--ilm"
            args = ["", "", "", "", run_ilm, "", ""]
            assert len(functions) == len(args)
            try:
                run_experiments(local_result_dir, "python", functions.keys(), "experiments/", ".verification_file", args=args, estimated_runtimes=list(functions.values()))
            except AssertionError:
                print("Experiments did not finish due to an error! Check the log for more details.")

        # Compile .tex to .pdf
        compile_main_pdf()
    finally:
        os.chdir(project_root)
