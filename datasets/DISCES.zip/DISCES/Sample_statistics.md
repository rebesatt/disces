Sample
- number of traces
- trace length distribution (min, max, average)
- type distribution for the sample

Traces
- type distribution (tracewise): 
	- most frequent type and number of occurrences
	- occurring and supported  types 

Types
- number of types, number of supported types (ratio)
- recurring events over traces

Patterns
- number of types that occur more than once in at least one trace
- min number of max repetition of a type in a trace
- number of recurring events for each trace

- Anzahl Matches, Länge, Type/Pattern, Anz von Matches pro Traces
- (Größe Queryset), Alphabet vs supported typeset, Types wie oft wiederholen


TODO: Korrelation von Eigenschaften mit Eigenschaften