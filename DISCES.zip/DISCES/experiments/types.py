import os
import sys
import pandas as pd
import glob
import numpy as np
import collections
from statistics import median, mean
from copy import deepcopy


CURRENT_WD = os.getcwd()

EXPERIMENT_DIR = os.path.abspath(__file__).replace("types.py", "")
os.chdir(EXPERIMENT_DIR)
os.chdir("../src")
SRC_DIR = os.getcwd()

os.chdir(EXPERIMENT_DIR)
sys.path.insert(0, SRC_DIR)

# Include files used for discovery here
from query_multidim import MultidimQuery
from sample_multidim import MultidimSample
from testbench_helper_functions import generate_plots, match_algos, _read_sample

def max_type(iterations:int, repetitions:int, overwrite:bool = False):
    file_name = f'max_type'
    file_path = f'experiment_results/{file_name}.csv'
    results = []
    sample_path = f'../datasets/synt/{file_name}'
    all_files = os.listdir(sample_path)
    file_list = [file.split('.')[0] for file in all_files]
    for file in file_list:
        j = int(file.split('_')[-1])
        new_sample_list = _read_sample(file,sample_path)
        for _ in range(repetitions):
            results, columns = match_algos(sample_list= new_sample_list, results=results, iterations=iterations,
                                            j=j+1, mod='max type', file_path=file_path)
        dataframe = pd.DataFrame(results, columns=columns)
        dataframe.to_csv(file_path)



if __name__ == "__main__":

    iterations = 10
    file_name = f'max_type'
    file_path = f'experiment_results/{file_name}.csv'
    if os.path.isfile(file_path):
        df1 = pd.read_csv(file_path)
    else:
        df1 = max_type(iterations=iterations, repetitions= 5, overwrite=False)
        df1['mode'] = 'type ratio'

    sample_path = f'../datasets/synt/{file_name}'
    df2 = deepcopy(df1)
    df3 = deepcopy(df1)
    df4 = deepcopy(df1)
    df5 = deepcopy(df1)

    df1['mode'] = 'type'
    df2['mode'] = 'max'
    df3['mode'] = 'sum'
    df4['mode'] = 'avg'
    df5['mode'] = 'med'

    d2_replace_dict = {}
    d3_replace_dict = {}
    d4_replace_dict = {}
    d5_replace_dict = {}
    all_files = os.listdir(sample_path)
    file_list = [file.split('.')[0] for file in all_files]
    for file in file_list:
        j = int(file.split('_')[-1]) +1
        sample_list = _read_sample(file, sample_path)
        sample = MultidimSample()
        sample.set_sample(sample_list)
        number_traces = len(sample_list)
        alphabet = sample.get_sample_supported_typeset()
        domain_sample_dict = sample.get_dim_sample_dict()
        max_types = 0
        max_sum_type = 0
        max_avg_type = 0
        max_med_type = 0
        
        domainsize = 0
        trace_length = 0
        number_types = 0

        max_type_list = []
        sum_type_list = []
        avg_type_list = []
        med_type_list = []

        for trace_id in range(number_traces):
            max_type_dom_list = []
            sum_type_dom_list = []
            avg_type_dom_list = []
            med_type_dom_list = []
            freq_list = []
            for dom_sample in domain_sample_dict.values():
                supported_alphabet = dom_sample.get_sample_supported_typeset()
                trace_list = dom_sample._sample[trace_id].split()
                trace_length = len(trace_list)
                event_counter = collections.Counter(trace_list)
                freq_dom_list = event_counter.most_common()
                type_sum = sum(tup[1] for tup in freq_dom_list if tup[0].replace(';','') in supported_alphabet)
                sum_type_dom_list.append(type_sum)
                for tup in freq_dom_list:
                    if tup[0].replace(';','') in supported_alphabet:
                        max_type_dom_list.append(tup[1])
                        break
                freq_list.extend([tup[1] for tup in freq_dom_list if tup[0].replace(';','') in supported_alphabet])
            max_type_list.append(max(max_type_dom_list, default=0))
            domain_sums = sum(sum_type_dom_list)
            sum_type_list.append(domain_sums)
            avg_type_list.append(mean(freq_list))
            med_type_list.append(median(freq_list))

        max_types = max(max_type_list, default=0)
        max_sum_type = max(sum_type_list, default=0)
        max_avg_type = max(avg_type_list, default=0)
        max_med_type = max(med_type_list, default=0)
        
        d2_replace_dict[j] = max_types
        d3_replace_dict[j] = max_sum_type
        d4_replace_dict[j] = max_avg_type
        d5_replace_dict[j] = max_med_type

        domainsize = len(domain_sample_dict)
        
        number_types = len(alphabet)

    df2.replace({'iterations': d2_replace_dict}, inplace=True)
    df3.replace({'iterations': d3_replace_dict}, inplace=True)
    df4.replace({'iterations': d4_replace_dict}, inplace=True)
    df5.replace({'iterations': d5_replace_dict}, inplace=True)


    frames = [df1, df2, df3, df4, df5]
    result = pd.concat(frames)
    result.to_csv('experiment_results/type.csv')

    file_name = 'type_plots'
    generate_plots(dataframe=result, file_name=file_name, x='iterations', y='time',
                    hue='algorithm', col = 'mode', col_wrap=3,kind='synt',
                    facet_kws={'sharex': False, 'sharey': False})
    # save plot of {experiment_name} to 'experiment_results/{experiment_name}.pdf'
    # Example: plot of 'sota_4_broken' to 'experiment_results/synt_plots.pdf'

    # Return to the origin
    os.chdir(CURRENT_WD)
